// import * as flsFunctions from './modules/functions.js';
// flsFunctions.isWebp();

// import Swiper, { Navigation, Pagination } from 'swiper';
// const swiper = new Swiper();


//<MODULES static>=============================
// import './modules/_static/';
// import './modules/_static/';
//</MODULES static>============================

// //<MODULES dynamic>============================
import './modules/main/burger-menu-and-smooth-scrolling.js';
import './modules/main/language.js';
import './modules/main/header-scroll.js';
import './modules/main/parallax.js';
import './modules/main/swiper.js';
import './modules/main/popup.js';
import './modules/main/popup-image.js';
import './modules/main/animationScroll.js';
// import './modules/main/';
// import './modules/main/';
//</MODULES dynamic>===========================