export let configFTP = {
	host: '', // Адреса FTP сервера
	user: '', // Ім'я користувача
	password: '', // Пароль
	parallel: 5 // Кількість одночасних потоків
}